#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

char** parse_cmdline(const char *cmdline);


char** parse_cmdline(const char *cmdline){
	int i=0, j;
	cmdline = (char*)malloc(100*sizeof(char));
	char **parsed;
	parsed = malloc(100*sizeof(char));
	ssize_t wres;
	for(j=0; cmdline[j]!='\0'; j++){
		char space = ' ';
		if(cmdline[j]==space){
			i++;
		}
		else{
			wres=write(parsed[i][j],cmdline+i,1); 
			if(wres<0){
				perror("write");
			}
			
		}
		
	}
	
	return parsed;
}


int main(){
	char *cmdline;
	cmdline = (char*)malloc(100*sizeof(char));
	printf("$ ");
	fgets(cmdline, 100, stdin);
	char **parsed;
	parsed = malloc(100*sizeof(char));
	parsed = parse_cmdline(cmdline);
	
	pid_t pid;
	pid = fork();

	
	if(pid > 0){//parent process
		waitpid(pid, NULL , 0); 
		}	
	else{
		if(pid==0){
			printf("$ ");
			for(int i=1;i<2;i++){
				//char* const* exe = &parsed[i];
				const char *filename="/bin/ls";
				execl(filename,filename,0);
			}	
		}

	}
	return 0;
}


