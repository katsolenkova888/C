		#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>

char** parse_cmdline(const char *cmdline);


char** parse_cmdline(const char *cmdline){

	int i=0, j = 100;
	
	char **parsed = (char**) malloc(j*sizeof(char*));
	
	int k = 0;
	//printf("%s",cmdline);
	char *tok;
	tok = strtok((char*)cmdline, " \n");
	while(tok != NULL){
		if(i==j){
			j*=2;	
			parsed = (char**)realloc(parsed,j*sizeof(char*));
		}
		
		parsed[i]=tok;
		tok = strtok (NULL, " \n");
		i++;
	}

	return parsed;
}


int main(){
	char *cmdline;
		while(1){

		write(STDOUT_FILENO,"$ ", 2);
		size_t capacity = 0;
		int size1 = getline(&cmdline, &capacity, stdin);
		if(size1 < 0){
			free(cmdline); 
			break;
		}
		cmdline[size1] = '\0';	
		char **parsed;
		parsed = parse_cmdline(cmdline);
		pid_t pid;
		pid = fork();
		if(pid==0){
			
				//printf("PID\n");
			const char *filename=parsed[0];
			int ex = execv(filename,parsed);
			if(ex<0){perror(filename);}
			free(parsed[0]);
			free(parsed);
		//	free(cmdline);
			exit(0);
				
				
		}
	
	 else if(pid > 0){//parent process
			waitpid(pid, 0, 0); 
			
	}
	else if(pid<0){

		perror("fork");

	}
		free(parsed[0]);
		free(parsed);
		//free(cmdline);		
		
	}
	
	
	return 0;
}


